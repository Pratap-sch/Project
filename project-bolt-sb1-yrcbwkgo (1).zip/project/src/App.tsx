import React, { useState, useEffect } from 'react';
import { Heart, SparklesIcon, Gift, ChevronLeft, ChevronRight } from 'lucide-react';

function App() {
  const [showProposal, setShowProposal] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showCelebration, setShowCelebration] = useState(false);

  const chocolateQuotes = [
    "Like fine chocolate, my love for you only gets better with time.",
    "Life is like a box of chocolates, but my choice will always be you.",
    "Sweet like chocolate, precious like you.",
    "In a world full of choices, you're my favorite flavor."
  ];

  const chocolateImages = [
    "https://images.unsplash.com/photo-1549007994-cb92caebd54b?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1481391319762-47dff72954d9?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1606312619070-d48b4c652a52?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1522159698025-071104a1ddbd?auto=format&fit=crop&q=80&w=800"
  ];

  const celebrationQuotes = [
    "Every moment with you is as sweet as chocolate melting in my mouth.",
    "You're the sweetness that makes my life complete.",
    "Together, we create the perfect blend of love and happiness.",
    "Like chocolate, you make everything better.",
    "Our love story is sweeter than any dessert.",
    "You're the missing ingredient in my recipe of life."
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % chocolateImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + chocolateImages.length) % chocolateImages.length);
  };

  const handleAccept = () => {
    setShowProposal(false);
    setShowCelebration(true);
  };

  if (showCelebration) {
    return <CelebrationPage quotes={celebrationQuotes} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-brown-50 to-red-50">
      {/* Hero Section */}
      <div className="relative h-screen">
        <div className="absolute inset-0 bg-black/40 z-10" />
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ 
            backgroundImage: 'url(https://images.unsplash.com/photo-1526081715791-7c538f86060e?auto=format&fit=crop&q=80&w=2000)',
            backgroundAttachment: 'fixed'
          }}
        />
        
        <div className="relative z-20 h-full flex flex-col items-center justify-center text-white px-4">
          <SparklesIcon className="w-12 h-12 mb-6 animate-twinkle text-yellow-300" />
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-center">
            Sweet Moments With You
          </h1>
          <p className="text-xl md:text-2xl text-center max-w-2xl mx-auto mb-8 italic">
            "All you need is love. But a little chocolate now and then doesn't hurt."
          </p>
          <button
            onClick={() => setShowProposal(true)}
            className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-full text-xl font-semibold transform transition hover:scale-105 flex items-center gap-2"
          >
            <Heart className="w-6 h-6" />
            Open Your Sweet Surprise
          </button>
        </div>
      </div>

      {/* Chocolate Slider */}
      <div className="py-20 px-4 bg-gradient-to-b from-brown-50/90 to-red-50/90 backdrop-blur-sm">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 text-brown-800">
            Sweet Moments Together
          </h2>
          <div className="relative group">
            <div className="relative h-[500px] overflow-hidden rounded-2xl shadow-xl">
              {chocolateImages.map((image, index) => (
                <div
                  key={index}
                  className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
                    index === currentSlide ? 'translate-x-0' : 'translate-x-full'
                  }`}
                  style={{
                    transform: `translateX(${(index - currentSlide) * 100}%)`
                  }}
                >
                  <img
                    src={image}
                    alt={`Chocolate ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <p className="text-white text-2xl font-medium text-center px-6 max-w-2xl animate-float">
                      {chocolateQuotes[index]}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Navigation Buttons */}
            <button
              onClick={prevSlide}
              className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-brown-800 p-2 rounded-full shadow-lg transition-all opacity-0 group-hover:opacity-100"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <button
              onClick={nextSlide}
              className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-brown-800 p-2 rounded-full shadow-lg transition-all opacity-0 group-hover:opacity-100"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Dots Navigation */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              {chocolateImages.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentSlide(index)}
                  className={`w-3 h-3 rounded-full transition-all ${
                    index === currentSlide ? 'bg-white scale-125' : 'bg-white/50'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Proposal Modal */}
      {showProposal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-8 max-w-2xl w-full animate-float">
            <div className="text-center">
              <Gift className="w-16 h-16 mx-auto mb-6 text-red-600" />
              <h3 className="text-3xl font-bold mb-4 text-brown-900">
                My Sweet Valentine
              </h3>
              <p className="text-lg mb-6 text-gray-700 leading-relaxed">
                Like chocolate, you bring sweetness to my life. Every moment with you is rich with joy and happiness. 
                Will you be my Valentine and make every day as sweet as chocolate?
              </p>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={handleAccept}
                  className="px-8 py-3 bg-red-600 text-white rounded-full hover:bg-red-700 transition flex items-center gap-2"
                >
                  <Heart className="w-5 h-5" fill="white" />
                  Yes, I Will!
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CelebrationPage({ quotes }: { quotes: string[] }) {
  useEffect(() => {
    const createChocolateRain = () => {
      const container = document.createElement('div');
      container.className = 'chocolate-rain';
      document.body.appendChild(container);

      const chocolateEmojis = ["🍫", "🍪", "🎂", "🧁"];
      const createChocolate = () => {
        const chocolate = document.createElement('div');
        const randomEmoji = chocolateEmojis[Math.floor(Math.random() * chocolateEmojis.length)];
        chocolate.textContent = randomEmoji;
        chocolate.style.left = `${Math.random() * 100}vw`;
        chocolate.style.animationDuration = `${Math.random() * 2 + 1}s`;
        container.appendChild(chocolate);

        chocolate.addEventListener('animationend', () => {
          container.removeChild(chocolate);
        });
      };

      // Create initial chocolates
      for (let i = 0; i < 20; i++) {
        createChocolate();
      }

      // Continuously create new chocolates
      const interval = setInterval(createChocolate, 300);

      return () => {
        clearInterval(interval);
        if (document.body.contains(container)) {
          document.body.removeChild(container);
        }
      };
    };

    return createChocolateRain();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-red-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full">
        <div className="text-center mb-12">
          <Heart className="w-16 h-16 text-red-500 mx-auto mb-6 animate-pulse" />
          <h1 className="text-4xl md:text-6xl font-bold text-red-600 mb-8">
            Thank You for Being My Valentine!
          </h1>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {quotes.map((quote, index) => (
            <div
              key={index}
              className="bg-white/80 backdrop-blur-sm p-6 rounded-xl shadow-lg transform hover:scale-105 transition-transform"
            >
              <p className="text-lg text-gray-800 italic">"{quote}"</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-2xl text-red-600 font-semibold">
            Let's make every moment as sweet as chocolate! ❤️
          </p>
        </div>
      </div>
    </div>
  );
}

export default App;